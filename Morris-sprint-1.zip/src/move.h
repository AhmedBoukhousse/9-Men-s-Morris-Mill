#pragma once

using namespace std;

class move
{

public:
	
	bool legalmoves(int);
	void movepiece(int,int);
};

