#ifndef TST_TESTPIECEPLACEMENT_H
#define TST_TESTPIECEPLACEMENT_H

#include <gtest/gtest.h>
#include <gmock/gmock-matchers.h>
#include "../src/board.h"


using namespace testing;

TEST(boardTest, testPiecePlacementSlot1)
{
    Board testBoard;
    testBoard.addPiece(1,1);
    ASSERT_THAT(testBoard.boardArea[1], Eq(1));
}

TEST(boardTest, testPiecePlacementPlayer2)
{
    Board testBoard;
    testBoard.addPiece(2,4);
    ASSERT_THAT(testBoard.boardArea[4], Eq(2));
}

TEST(boardTest, testPiecePlacementNoneLeft)
{
    Board testBoard;
    testBoard.playerPieces[1] = 9;
    testBoard.addPiece(1,4);
    ASSERT_THAT(testBoard.boardArea[4], Eq(0));
}

#endif // TST_TESTPIECEPLACEMENT_H
