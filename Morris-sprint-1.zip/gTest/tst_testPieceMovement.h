#ifndef TST_TESTPIECEMOVEMENT_H
#define TST_TESTPIECEMOVEMENT_H

#include <gtest/gtest.h>
#include <gmock/gmock-matchers.h>
#include "../src/board.h"

using namespace testing;


TEST(boardTest, testPieceMovementToBlankIsFirstSpotClear)
{
    Board testBoard;
    testBoard.addPiece(1,4);
    testBoard.swapPiece(1,4,5);
    ASSERT_THAT(testBoard.boardArea[4], Eq(0));
}

TEST(boardTest, testPieceMovementToBlankIsSecondSpotFilled)
{
    Board testBoard;
    testBoard.addPiece(1,4);
    testBoard.swapPiece(1,4,5);
    ASSERT_THAT(testBoard.boardArea[5], Eq(1));
}

TEST(boardTest, testPieceMovementToOccupied)
{
    Board testBoard;
    testBoard.addPiece(2,4);
    testBoard.addPiece(1,5);
    testBoard.swapPiece(1,5,4);
    ASSERT_THAT(testBoard.boardArea[4], Eq(2));
}

#endif // TST_TESTPIECEMOVEMENT_H


